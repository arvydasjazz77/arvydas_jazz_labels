<?php
    if(isset($_POST['Submit'])){

        $customer = trim($_POST['name']);
        $email = trim($_POST['email']);
        $message = trim($_POST['message']);
        
        if(!empty($customer) && !empty($email) && !empty($message)){
            if(filter_var($email, FILTER_VALIDATE_EMAIL)){
                $from = "$email";
                $to = "arvydasjazz77@gmail.com";
                $subject = "Gauta nauja žinutė";
                $autorius  = 'Nuo: ' . $customer . ', ' .$email;
                $zinute = htmlspecialchars($message);
                //mail($to, $subject, $autorius, $zinute, $from);
                echo "<script>alert('Thank you $customer! Your message has been successfully sent. We will contact you very soon!');</script>";
            }
        }
        include 'db.php';
    }
