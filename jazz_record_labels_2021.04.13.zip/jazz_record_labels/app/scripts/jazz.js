$(document).ready(function(){
    // Pridedu smooth scrolling visoms nuorodoms, kurios yra id
    $("a").on('click', function(event) {
        // Patikrinu ar hashtag (#) turi reikšmę
        if (this.hash !== "") {
            // Prevent default anchor click behavior
            event.preventDefault();        
            // Talpinu hash į kintamąjį
            var hash = this.hash;
                // Using jQuery's animate() method to add smooth page scroll
                // Uždėjau 1000 milisekundžių, kad nuvažiuotų į reikiamą poziciją
                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                    }, 900, function(){     
                    // Pridedu hash (#) prie URL kai scrolling'as baigtas (default click behavior)
                    window.location.hash = hash;
                });
        } // End if
    });
    $(".learn-more,.order-list,.getQuote").click(function () {
        var hash;
        if($(".learn-more").index(this)==0){
            hash = '#film';
        }
        else if($(".order-list").index(this)==0){
            hash = '#contact-heading';
        }
        else if($(".getQuote").index(this)==0){
            hash = '#contact-heading';
        }        
        $('html, body').animate({
            scrollTop: $(hash).offset().top}, 900, function(){     
            window.location.hash = hash;
        });  
    });
});



