<!--Dvylikta dalis Footer-->
<footer class="footer">
    <div class="container">
        <p>&copy;<?php echo date('Y'); ?> Magma Jazz. All rights reserved.</p>
    </div>
</footer>