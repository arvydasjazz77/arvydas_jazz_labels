<!--Pirma dalis Header-->
<header class="site-header">
    <div class="container flex-container">
        <div class="logo">
        <a href="#jazz-hero"><img src="../app/images/logo_header.png" alt="Magma Jazz"></a>
        </div>
        <nav class="main-nav">
            <ul class="flex-container">
                <li><a href="#jazz-hero">Home</a></li>                        
                <li><a href="#records">Records</a></li>
                <li><a href="#jstyles">JStyles</a></li>
                <li><a href="#contact-heading">Contact</a></li>               
            </ul>
        </nav>
    </div>
</header>