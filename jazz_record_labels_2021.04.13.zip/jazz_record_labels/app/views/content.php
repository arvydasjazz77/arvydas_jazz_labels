<!--Antra dalis Jazz Hero -->
<section id="jazz-hero">                                    
    <div class="jazz-container">                
        <div id ="jazz-logo">Jazz</div>                                          
        <h1>The Greatest Jazz Record Labels & Companies</h1>
        <p>Plus Their Most Essential Artist and 10 Albums They Recorded. Jazz Styles and Genres.</p>
        <nav class="jazz-nav">
            <ul class="button-container">                                      
                <li><button class= "learn-more">Learn More</button></li>
                <li><button class= "order-list">Order List</button></li>
            </ul>
        </nav>            
    </div>                       
    <div id="film"></div>
</section>    
<!--Trečia dalis Documentary -->
<section class="documentary">                
    <div class="doc-container">
        <div class="a-dovegray"></div>
        <ul class="calle-doc">                                
            <li><h3>Calle 54 <span> Documentary, Music 06 October 2000 (Spain)</span></h3></li>
            <li><p>Fernando Trueba presents his love affair with Latin jazz, his camera following 13 giants into the studio. Trueba drapes walls with single colors - red for Jerry González and the Fort Apache band, white for Tito Puente; his camera is close to faces, instruments, hands, and feet; bands' colors contrast with walls or their leader's clothes. Chucho Valdés does a pyrotechnic solo then joins his aged father Bebo for a subdued duet. Puntilla Ríos takes us to Africa, Chano Domínguez to a marriage of jazz and Flamenco, and Eliane Elias, her shoe-less foot on the pedal, to gorgeous and muscular elegance. With Paquito, Cachao, Patato, Chico, Gato, and Michel Camilo, we travel Calle 54.</p></li>                
            <li><a href="https://www.youtube.com/watch?v=7qw25NcW5ps" target="_blank"><i class="fas fa-arrow-right"></i></a></li>
        </ul>
        <div class="doc-video">                    
            <iframe width="564" height="349" src="https://www.youtube.com/embed/axTfqxahqEE" title="YouTube video player" allow="accelerometer; autoplay=0; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        <div class="b-dovegray"></div>
    </div>
</section> 
<!--Ketvirta dalis Statictic-->
<section class="statistic">                
    <div class="stat-container">
        <div class="a-softgreen"></div>
        <div class="b-softgreen"></div>
        <div class="c-softgreen"></div>
        <div class="mainbox-container">
            <div class="mxb-container">
                <div class ="stat-text">Some statistics and what you will find here!</div>
                <div class="stat-info">
                <p>We are presenting the Greatest Jazz Record Labels & Companies and their most Essential Artist and 10 Albums they recorded: Columbia (Miles Davis), Blue Note (Lee Morgan), Riverside (Thelonious Monk), Impulse! (John Coltrane), Verve (Herbie Hancock), Atlantic (Charles Mingus), Mercury/EmArcy (Clifford Brown/Max Roach), Prestige (Miles Davis Quintet), Pacific (Chet Baker), Savoy (Charlie Parker/Dizzy Gillespie).</p>
                </div>
                <div class="statfirst-container">
                    <ul class="stat-first">
                        <li><h2>100</h2></li>
                        <li>Jazz Albums</li>
                    </ul>
                    <ul class="stat-second">
                        <li><h2>78</h2></li>
                        <li>Jazz Artists</li>
                    </ul>
                </div>
                <div class="statsecond-container">
                    <ul class="stat-first">
                        <li><h2>10</h2></li>
                        <li>Record labels</li>
                    </ul>
                    <ul class="stat-second">
                        <li><h2>47</h2></li>
                        <li>Jazz Genres</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="jstyles"></div>             
</section>
<!-- Penkta dalis Jazz Styles Periods  -->
<section class="jstyle">
    <div class="jstyle-container">
        <div id="jstyle-heading">
            <h2>The Main Jazz <span class="special-word">Styles Periods</span></h2>
        </div>
        <div class ="jsperiod-container">
            <div class ="jsperiod1 jsdetail">
                <img src="../app/images/period01.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Early Jazz/New Orleans & Chicago Style Dixieland</h3></li>                            
                    <li><span>Characteristics: </span>Use of collective improvisation (polyphony). Front line of trumpet (or cornet),
                    clarinet, trombone. New Orleans style typically included banjo and tuba, later replaced by guitar and string
                    bass in Chicago Style. Chicago Style also typically adds saxophone to the front line. Use of flat four in New
                    Orleans Style, later replaced by lighter two beat feel in Chicago Style. Modern drum set emerges when New
                    Orleans musicians begin to consolidate the drum section (bass, snare, cymbals) commonly found in early
                    New Orleans brass bands.
                    </li>
                    <li><span>Important musicians: </span>Louis Armstrong (cornet / trumpet), Bix Beiderbecke (cornet), Jelly Roll Morton
                    (piano/composer), Sidney Bechet (soprano sax, clarinet), Earl "Fatha" Hines (piano)
                    </li>
                </ul>
            </div>
            <div class ="jsperiod2 jsdetail">
                <img src="../app/images/period02.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Swing/Big Band Era</h3></li>                            
                    <li><span>Characteristics: </span>Most popular period in jazz history. Large ensembles, less improvisation, more
                        emphasis on written arrangements. Emphasis on showmanship (band uniforms, theme songs, logos on
                        stands, choreography, singers). Development of sections (saxes, trumpets, trombones, rhythm) based on
                        the early model of the front line in New Orleans/Chicago Style Dixieland. Smoother swing feel (steady 4/4
                        time with emphasis on beats 2 & 4, walking bass, ride cymbal). Features of standard big band
                        arrangements could include: Tutti (all horns playing a melodic line in harmony), Soli (one section featured
                        playing a melodic line in harmony), Shout Chorus (climatic tutti section at the end of the arrangement),
                        Cross-section voicing (a harmonized melodic line voiced using instruments from different sections within the
                        band), Riffs (repeated short melodic and/or rhythmic pattern).
                        </li>
                    <li><span>Important musicians: </span>Duke Ellington (piano / composer), Count Basie (piano / bandleader), Coleman
                        Hawkins (tenor sax), Lester Young (tenor sax), Roy Eldridge (trumpet)
                        </li>
                </ul>
            </div>
            <div class ="jsperiod3 jsdetail">
                <img src="../app/images/period03.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Bop</h3></li>                            
                    <li><span>Characteristics: </span>Small ensembles (trio, quartet, quintet). Focus on improvisation rather than on
                        complex arrangements. Complex, angular melodies usually played in unison. Longer, irregular phrasing.
                        Usually faster tempos than in swing. Emphasis on virtuosity, instrumental technique. Drummer is now more
                        interactive (dropping bombs) with soloist. Use of contrafacts (original melody lines written over standard
                        chord progressions). Increased harmonic complexit–ies (alterations and substitutions of standard chord
                        progressions).
                        </li>
                    <li><span>Important musicians: </span>Charlie Parker (alto sax), Dizzy Gillespie (trumpet), Bud Powell (piano),
                        Thelonious Monk (piano/composer), Max Roach (drums), Dexter Gordon (tenor sax), J.J. Johnson
                        (trombone)
                        </li>
                </ul>
            </div>
            <div class ="jsperiod4 jsdetail">
                <img src="../app/images/period04.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Cool</h3></li>                            
                    <li><span>Characteristics: </span>Calm, unhurried approach to improvisation. Thinner textures, softer dynamics,
                        smoother melodic phrasing. Horn players tend to play with a lighter, less harsh tone quality with little vibrato
                        (influence of Lester Young). Less intense kicks/bombs by drummers, increased use of brushes. More
                        intricate arrangements, an emphasis on composition. New instrumental combinations (flute, cello, french
                        horn, oboe, etc.). Renewed interest of collective improvisation. Less obvious blues influence.
                        </li>
                    <li><span>Important musicians: </span>Miles Davis (trumpet), Dave Brubeck (piano/composer), Paul Desmond & Lee
                        Konitz (alto sax), Gerry Mulligan (bari sax/composer), Modern Jazz Quartet, Stan Getz (tenor sax), Gil
                        Evans (piano/composer)
                        </li>
                </ul>
            </div>  
            <div class ="jsperiod5 jsdetail">
                <img src="../app/images/period05.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Hard Bop</h3></li>                            
                    <li><span>Characteristics: </span>Raw, hard driving style with an emotional emphasis. Extensive use of the blues &
                        gospel music. Emphasis on "groove" (funky), danceability and the "shuffle" rhythm. Latin elements and a
                        "straight" eighth note feel used at times. Somewhat slower tempos and simpler melodies than in bop.
                        Primarily black musicians from New York City, Detroit and Philadelphia.
                        </li>
                    <li><span>Important musicians: </span>Art Blakey (drums) & The Jazz Messengers, Horace Silver (piano), Sonny
                        Rollins (tenor sax), Clifford Brown (trumpet), Cannonball Adderley (alto sax), Charles Mingus (bass/
                        composer), Benny Golson (tenor sax/composer) & The Jazztet, Miles Davis' (trumpet) "classic" quintet
                        (1955-59)
                        </li>
                </ul>
            </div>  
            <div class ="jsperiod6 jsdetail">
                <img src="../app/images/period06.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Free Jazz/Avant Garde</h3></li>                            
                    <li><span>Characteristics: </span>Open or free forms; tunes often complete improvisations. Lack of preset chord
                        changes. Usually dense textures, high energy playing (energy music). Collective improvisation of a more
                        dissonant, atonal nature. Oftentimes ensembles omit use of a piano or chord instrument. Experimental
                        instruments & instrumentations. Use of unorthodox sounds (squeaks, screams, noise, etc) and extended
                        techniques (altissimo register, multiphonics, etc). Interest in non-western musical concepts (world music)
                        and 20th century classical composers such as John Cage and Karlheinz Stockhausen.
                        </li>
                    <li><span>Important musicians: </span>Ornette Coleman (alto sax / composer), Cecil Taylor (piano / composer), Albert
                        Ayler (tenor sax), Anthony Braxton (saxophones / composer)
                        </li>
                </ul>
            </div>  
            <div class ="jsperiod7 jsdetail">
                <img src="../app/images/period07.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Fusion/Jazz-Rock</h3></li>                            
                    <li><span>Characteristics: </span>Extensive use of electronic instruments: electric piano (Fender Rhodes),
                        synthesizers (multiple keyboards), electric bass (bass guitar), electric guitar, electronic modifications on
                        acoustic instruments. Focus of attention on the rhythm section. More attention on studio recording
                        technology and the process of recording. More emphasis on straight eighth note feel (rock) than on swing.
                        Harmony often simple chord repetitions (static harmony, vamps). Bass lines often repetitive. Pieces range
                        from simple melodies with vamps and open forms to complex through-composed , sectionalized
                        compositions. Saxophones used more often than brass instruments.
                        </li>
                    <li><span>Important musicians: </span>Miles Davis (trumpet / bandleader: Bitches' Brew, In A Silent Way), Chick Corea
                        (keyboards/leader: Return to Forever), Weather Report (group), John McLaughlin (guitar/leader:
                        Mahavishnu Orchestra)
                        </li>
                </ul>
            </div>  
            <div class ="jsperiod8 jsdetail">
                <img src="../app/images/period08.png" alt="Jazz Style Period">
                <ul class="period-list">
                    <li><h3>Eclecticism</h3></li>                            
                    <li><span>Characteristics: </span>No single dominant stylistic trend has emerged in the 1980s or 90s. Instead, a
                        continuation of previous styles, crossovers, and new styles derived from various sources are common.
                        Some notable trends within this eclecticism seem to be: 1) a further sophistication of electronic jazz through
                        the use of computers, 2) a resurgent neo-bop and neo-traditionalist movement (Neo-Classicism), 3)
                        expanded instrumental & vocal techniques, 4) a greater involvement of women, and 5) the growth of
                        European and "world music" jazz styles.                                
                        </li>
                    <li><span>Important musicians: </span>Pat Metheny Group (fusion band), Michael Brecker (tenor sax: also founding
                        member of fusion group Steps Ahead), Wynton Marsalis (trumpet/composer: associated with Neo-Classic
                        movement), Joe Lovano (tenor sax), Kenny Garrett (alto sax), Don Byron (clarinet/composer), Dave Douglas
                        (trumpet/composer), Bobby McFerrin (voice), Steve Coleman (alto sax), Cassandra Wilson (voice), Dave Sanborn (alto sax), Chick
                        Corea's Elektric Band (fusion band), John Scofield (guitar), Keith Jarrett Trio (piano/bass/drums, jazz trio)
                        </li>
                </ul>
            </div>                   
        </div>                
    </div>    
    <div id="records"></div>        
</section>            
<!--Šešta dalis Record Label & Companies -->
<section class="record-label">
    <div class="record-container">
        <div id="record-heading">
            <h2>The Greatest Jazz <span class="special-word">Record Labels & Companies</span></h2>
        </div>
        <div class ="disc-container">
            <div class="disc1">
                <div class = "disc-cover"><a href="https://g.co/kgs/LUU2ZZ" target="_blank"><img src="../app/images/Kind_of_Blue_Columbia01.png" title="Kind of Blue - Miles Davis" alt="Kind of Blue"></a></div>
                <div class = "disc-company"><a href="https://www.columbiarecords.com/" target="_blank"><h3>Columbia Records</h3></a></div>
                <a href="https://g.co/kgs/pdZ5Rz" target="_blank"><p>Miles Davis  | Artist</p></a>
                <ol class="disc-list">
                    <li>Kind of Blue  <span>(Miles Davis)</span></li>
                    <li>Ellington At Newport 1956  <span>(Duke Ellington)</span></li>
                    <li>Lady in Satin  <span>(Billie Holliday)</span></li>
                    <li>Mingus Ah Um  <span>(Charles Mingus)</span></li>
                    <li>Time Out  <span>(Dave Brubeck)</span></li>
                    <li>Heavy Weather  <span>(Weather Report)</span></li>
                    <li>Headhunters  <span>(Herbie Hancock)</span></li>
                    <li>Straight, No Chaser  <span>(Thelonious Monk)</span></li>
                    <li>Satch Plays Fats  <span>(Louis Armstrong)</span></li>
                    <li>Black Codes (From the Underground)  <span>(Wynton Marsalis)</span></li>                         
                </ol>
            </div>
            <div class="disc2">
                <div class = "disc-cover"><a href="https://g.co/kgs/mgBhYi" target="_blank"><img src="../app/images/Song_For_My_Father_BlueNote02.png" title="Song For My Father - Horace Silver" alt="Song For My Father"></a></div>
                <div class = "disc-company"><a href="http://www.bluenote.com" target="_blank"><h3>Blue Note</h3></a></div>
                <a href="https://g.co/kgs/kLL6YN" target="_blank"><p>Lee Morgan | Artist</p></a>
                <ol class="disc-list">   
                    <li>Song For My Father  <span>(Horace Silver)</span></li>
                    <li>Out To Lunch  <span>(Eric Dolphy)</span></li>
                    <li>Somethin' Else  <span>(Cannonball Adderley)</span></li>
                    <li>Idle Moments  <span>(Grant Green)</span></li>
                    <li>Speak No Evil  <span>(Wayne Shorter)</span></li>
                    <li>The Sidewinder  <span>(Lee Morgan)</span></li>
                    <li>Birth of the Cool  <span>(Miles Davis)</span></li>
                    <li>Maiden Voyage  <span>(Herbie Hancock)</span></li>
                    <li>Go!  <span>(Dexter Gordon)</span></li>
                    <li>Moanin'  <span>(Art Blakey)</span></li>                          
                </ol>
            </div>
            <div class="disc3">
                <div class = "disc-cover"><a href="https://g.co/kgs/fJKwKM" target="_blank"><img src="../app/images/Brilliant_Corners_Riverside03.png" title="Brilliant Corners - Thelonious Monk" alt="Brilliant Corners"></a></div>
                <div class = "disc-company"><a href="https://concord.com/labels/riverside/" target="_blank"><h3>Riverside Records</h3></a></div>
                <a href="https://g.co/kgs/NDyk5h" target="_blank"><p>Thelonious Monk | Artist</p></a>
                <ol class="disc-list">   
                    <li>Brilliant Corners  <span>(Thelonious Monk)</span></li>
                    <li>Incredible Jazz Guitar  <span>(Wes Montgomery)</span></li>
                    <li>Thelnious Monk with John Coltrane  <span>(Thelonious Monk / John Coltrane)</span></li>
                    <li>Creole Reeds  <span>(Sidney Bechet)</span></li>
                    <li>Big 6!  <span>(Blue Mitchell)</span></li>
                    <li>Monk's Music  <span>(Thelonious Monk)</span></li>
                    <li>Plays Duke Ellington  <span>(Thelonious Monk)</span></li>
                    <li>It's Magic  <span>(Abbey Lincoln)</span></li>
                    <li>Caravan  <span>(Art Blakey)</span></li>
                    <li>Chet  <span>(Chet Baker)</span></li>                           
                </ol>
            </div>  
            <div class="disc4">
                <div class = "disc-cover"><a href="https://g.co/kgs/JPLZKY" target="_blank"><img src="../app/images/A_Love_Supreme_Impulse04.png" title="A Love Supreme - John Coltrane" alt="A Love Supreme"></a></div>
                <div class = "disc-company"><a href="http://www.impulserecords.com/" target="_blank"><h3>Impulse! Records</h3></a></div>
                <a href="https://g.co/kgs/E8K5Jg" target="_blank"><p>John Coltrane | Artist</p></a>
                <ol class="disc-list">   
                    <li>A Love Supreme  <span>(John Coltrane)</span></li>
                    <li>Sarah Vaughan with Clifford Brown  <span>(Sarah Vaughan / Clifford Brown)</span></li>
                    <li>Ella and Louis  <span>(Ella Fitzgerald / Louis Armstrong)</span></li>
                    <li>Getz/Gilberto  <span>(Stan Getz / Joao Gilberto)</span></li>
                    <li>The Composer of Desafinado Plays  <span>(Antonio Carlos Jobim)</span></li>
                    <li>John Coltrane and Johnny Hartman  <span>(John Coltrane / Johnny Hartman)</span></li>
                    <li>Death and the Flower  <span>(Keith Jarrett)</span></li>
                    <li>The Black Saint and the Sinner Lady  <span>(Charles Mingus)</span></li>
                    <li>Ascension  <span>(John Coltrane)</span></li>
                    <li>The Blues and the Abstract Truth  <span>(Oliver Nelson)</span></li>                            
                </ol>
            </div>
            <div class="disc5">
                <div class="disc-cover"><a href="https://g.co/kgs/LdDNgK" target="_blank"><img
                src="../app/images/Directions_in_Music_Verve05.png" title="Directions in Music - Herbie Hancock / Micheal Brecker / Roy Hargrove" alt="Directions in Music"></a></div>                        
                <div class = "disc-company"><a href="http://www.ververecords.com/" target="_blank"><h3>Verve Records</h3></a></div>
                <a href="https://g.co/kgs/v1LpVz" target="_blank"><p>Herbie Hancock | Artist</p></a>
                <ol class="disc-list">
                    <li>Directions in Music  <span>(Herbie Hancock / Micheal Brecker / Roy Hargrove)</span></li>
                    <li>Snap Your Fingers  <span>(Al Grey)</span></li>
                    <li>Blues: The Common Ground  <span>(Kenny Burrell)</span></li>
                    <li>Giblet Gravy  <span>(George Benson)</span></li>
                    <li>What the World Needs Now  <span>(Stan Getz)</span></li>
                    <li>Roy and Diz  <span>(Roy Eldridge / Dizzy Gillespie)</span></li>
                    <li>Lovesome Things  <span>(Joe Henderson)</span></li>
                    <li>1+1  <span>(Herbie Hancock / Wayne Shorter)</span></li>
                    <li>California Dreaming  <span>(Wes Montgomery)</span></li>
                    <li>Parallel Realities  <span>(Jack DeJohnette)</span></li>                      
                </ol>
            </div>
            <div class="disc6">
                <div class = "disc-cover"><a href="https://g.co/kgs/6FSUKb" target="_blank"><img src="../app/images/Shape_of_Jazz_to_Come_Atlantic06.png" title="The Shape of Jazz to Come - Ornette Colemans" alt="The Shape of Jazz to Come"></a></div>
                <div class = "disc-company"><a href="https://www.atlanticrecords.com/" target="_blank"><h3>Atlantic Records</h3></a></div>
                <a href="https://g.co/kgs/cB43Rk" target="_blank"><p>Charles Mingus</p></a>
                <ol class="disc-list">
                    <li>The Shape of Jazz to Come  <span>(Ornette Coleman)</span></li>
                    <li>Giant Steps  <span>(John Coltrane)</span></li>
                    <li>Reunion at Budokan  <span>(The Modern Jazz Quartet)</span></li>
                    <li>Blues & Roots  <span>(Charles Mingus)</span></li>
                    <li>Art Blakey and Thelonious Monk  <span>(Art Blakey / Thelonious Monk)</span></li>
                    <li>Free Jazz  <span>(Ornette Coleman)</span></li>
                    <li>My Favorite Things  <span>(John Coltrane)</span></li>
                    <li>The Clown  <span>(Charles Mingus)</span></li>
                    <li>For Love or Country  <span>(Arturo Sandoval)</span></li>
                    <li>Mingus at Antibes  <span>(Charles Mingus)</span></li>                            
                </ol>                        
            </div>
            <div class="disc7">
                <div class = "disc-cover"><a href="https://g.co/kgs/Z71J8d" target="_blank"><img src="../app/images/Dinah_Jams_EmArcy07.png" title="Dinah Jams - Dinah Washington" alt="Dinah Jams"></a></div>
                <div class = "disc-company"><a href="https://www.universalmusic.com/" target="_blank"><h3>Mercury/EmArcy Records</h3></a></div>
                <a href="https://g.co/kgs/7JXTp6" target="_blank"><p>Clifford Brown/Max Roach | Artist</p></a>
                <ol class="disc-list">
                    <li>Dinah Jams  <span>(Dinah Washington)</span></li>
                    <li>Rip, Rig, and Panic  <span>(Rahsaan Roland Kirk)</span></li>
                    <li>At the Piano  <span>(Errol Garner)</span></li>
                    <li>The Bean  <span>(Coleman Hawkins)</span></li>
                    <li>The Big Tenor  <span>(Ben Webster)</span></li>
                    <li>With Strings  <span>(Clifford Brown)</span></li>
                    <li>I Surrender, Dear  <span>(Billy Eckstine)</span></li>
                    <li>For Those in Love  <span>(Dinah Washington)</span></li>
                    <li>Clark Terry  <span>(Clark Terry)</span></li>
                    <li>And His Octet  <span>(Maynard Ferguson)</span></li>
                </ol>
            </div>
            <div class="disc8">
                <div class = "disc-cover"><a href="https://g.co/kgs/4SSLdD" target="_blank"><img src="../app/images/Saxophone_Colossus_Prextige08.png" title="Saxophone Colossus - Sonny Rollins" alt="Saxophone Colossus"></a></div>
                <div class = "disc-company"><a href="https://concord.com/labels/prestige-records/" target="_blank"><h3>Prestige Records</h3></a></div>
                <a href="https://g.co/kgs/X9sgyk" target="_blank"><p>Miles Davis Quintet | Artist</p></a>
                <ol class="disc-list">
                    <li>Saxophone Colossus  <span>(Sonny Rollins)</span></li>
                    <li>The Miles Davis Quintet Series  <span>(Miles Davis)</span></li>
                    <li>Django  <span>(Modern Jazz Quartet)</span></li>
                    <li>Dizzy Atmosphere  <span>(Lee Morgan / Wynton Kelly)</span></li>
                    <li>Harlem  <span>(Duke Ellington)</span></li>
                    <li>Bags' Groove  <span>(Miles Davis)</span></li>
                    <li>Eric Dolphy  <span>(Eric Dolphy)</span></li>
                    <li>Mating Call  <span>(John Coltrane)</span></li>
                    <li>Recorded Live! In Concert Around the World  <span>(Jack McDuff)</span></li>
                    <li>Up Tight!  <span>(Gene Ammons)</span></li>
                </ol>
            </div> 
            <div class="disc9">
                <div class = "disc-cover"><a href="https://g.co/kgs/x53wHR" target="_blank"><img src="../app/images/Quartet_Pacific09.png" title="Quartet - Gerry Mulligan" alt="Quartet"></a></div>
                <div class = "disc-company"><a href="https://www.universalmusic.com/label/capitol-music-group/" target="_blank"><h3>Pacific Jazz</h3></a></div>
                <a href="https://g.co/kgs/XFSnKa" target="_blank"><p>Chet Baker | Artist</p></a>
                <ol class="disc-list">
                    <li>Quartet  <span>(Gerry Mulligan)</span></li>
                    <li>Chet Baker Sings!  <span>(Chet Baker)</span></li>
                    <li>Sweets At The Hait  <span>(Harry "Sweets" Edison)</span></li>
                    <li>Flute 'N Oboe  <span>(Bud Shanks / Bob Cooper)</span></li>
                    <li>Sings a Song With Mulligan  <span>(Annie Ross / Gerry Mulligan)</span></li>
                    <li>Ritual  <span>(Art Blakey)</span></li>
                    <li>New Bottle, Old Wine  <span>(Cannonball Adderley / Gil Evans)</span></li>
                    <li>Critic's Choice  <span>(Pepper Adams)</span></li>
                    <li>Jazz Immortal  <span>(Clifford Brown)</span></li>
                    <li>It's About Time  <span>(Teddy Edwards)</span></li>
                </ol>
            </div> 
            <div class="disc10">
                <div class = "disc-cover"><a href="https://g.co/kgs/cUHKmQ" target="_blank"><img src="../app/images/Penthouse_Serenade_Savoy10.png" title="Penthouse Serenade - Errol Garner" alt="Penthouse Serenade"></a></div>
                <div class = "disc-company"><a href="https://concord.com/labels/savoy-label-group/" target="_blank"><h3>Savoy Record</h3></a></div>
                <a href="https://g.co/kgs/ndnker" target="_blank"><p>Charlie Parker/Dizzy Gillespie | Artist</p></a>
                <ol class="disc-list">
                    <li>Penthouse Serenade <span>(Erroll Garner)</span></li>
                    <li>Jay and Kai  <span>(J.J. Johnson / Kai Winding)</span></li>
                    <li>Bohemia After Dark  <span>(Kenny Clarke)</span></li>
                    <li>Groovin' High  <span>(Dizzy Gillespie)</span></li>
                    <li>With Milt Jackson  <span>(Howard McGhee / Milt Jackson)</span></li>
                    <li>Borderline  <span>(Ray McKinley)</span></li>
                    <li>That's Nat  <span>(Nat Adderley)</span></li>
                    <li>The Champ  <span>(Dizzy Gillespie)</span></li>
                    <li>The Immortal  <span>(Charlie Parker)</span></li>
                    <li>Jackson's Ville  <span>(Milt Jackson)</span></li>

                </ol>
            </div>                     
        </div>
    </div>
</section>        
<!-- Septinta dalis Contact -->
<section class="contact-hero">
    <div class="container">
        <div class="section-heading">
            <h1>Contact</h1>
        </div>
    </div>
</section>
<!-- Aštunta dalis Kontaktinė forma -->
<section class="contact">            
    <div class="container contact-grid">
        <div class ="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d9931.944488756482!2d-0.131535!3d51.5134706!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x47959a8451693090!2sRonnie%20Scott&#39;s!5e0!3m2!1sen!2slt!4v1617635889785!5m2!1sen!2slt"
            width="100" height="100" style=border:0 allowfullscreen></iframe>
        </div>
        <div class="blockA">
            <p>Jazz Club</p>
        </div>                    
        <div class="jazz-club">                    
            <p id="clubName">Ronnie Scott's</p>
            <p id="clubInfo">European vanguard for jazz and blues from world's top musicians, in basement club with late bar.</p>
        </div>                
        <div class="blockB">
            <ul class="address-info">
                <li><i class="far fa-map fa-2x"></i></li>
                <li><h4>Address</h4></li>
                <li><a href="https://goo.gl/maps/w2eHpSDSEPg8VUSF7" target="_blank">47 Frith St, Soho, London</a></li>
                <li><a href="https://goo.gl/maps/w2eHpSDSEPg8VUSF7" target="_blank">W1D 4HT, United Kingdom</a></li>                       
                <li><br></li>
                <li>Sun: 6:30 PM - 12:00 AM</li>
                <li>Mon–Sat: 6:00PM - 3:00 AM<li>                                            
            </ul> 
        </div>                    
        <div class="blockD">                    
            <ul class="call-info">
                <li><i class="fas fa-phone-alt fa-2x"></i></li>
                <li><h4>Phone & Email</h4></li>
                <li><a href="tel:+4402074390747">Phone: +4402074390747</a></li>
                <li><a href="tel:+4402074375081">Fax: +4402074375081</a></li>
                <li><br></li>
                <li>Email:</li>
                <li><a href="mailto:ronniescotts@ronniescotts.co.uk">ronniescotts@ronniescotts.co.uk</a></li>                                             
            </ul>          
        </div>     
        <div class="blockC"></div>
        <div id="contact-heading">                    
            <h2>Contact form</h2>                    
        </div>                
        <div class="section-content">                    
            <form class="contact-form" action="index.php" method="post">
                <div class="input-row">                            
                    <input type="text" name="name" placeholder="Your Name*" required>
                    <input type="email" name="email" placeholder="Your Email*" required>
                </div>
                <textarea name="message" rows="8" placeholder="Your Message*" required></textarea>
                <input class="btn-form" type="submit" name="Submit">
                <p>We provide a professional service for listeners and friends.</p>
            </form>
        </div>
    </div>
</section>
<!--Devinta dalis Companies logos -->
<div class="company">
    <div class="container">
        <div class="company-logos">  
            <div><a href="http://www.bluenote.com" target="_blank"><img src="../app/images/logo_bluenote.png" title="Blue Note" alt="Blue Note"></a></div>
            <div><a href="https://www.columbiarecords.com/" target="_blank"><img src="../app/images/logo_columbia.png" title="Columbia Records" alt="Columbia Records"></a></div>                    
            <div><a href="https://concord.com/labels/riverside/" target="_blank"><img src="../app/images/logo_riverside.png" title="Riverside Records" alt="Riverside Records"></a></div>
            <div><a href="http://www.impulserecords.com/" target="_blank"><img src="../app/images/logo_impulse.png" title="Impulse! Records" alt="Impulse! Records"></a></div>
            <div><a href="http://www.ververecords.com/" target="_blank"><img src="../app/images/logo_verve.png" title="Verve Records" alt="Verve Records"></a></div>
            <div><a href="https://www.atlanticrecords.com/" target="_blank"><img src="../app/images/logo_atlantic.png" title="Atlantic Records" alt="Atlantic Records"></a></div>
            <div><a href="https://www.universalmusic.com/" target="_blank"><img src="../app/images/logo_emarcy.png" title="Mercury/EmArcy Records" alt="Mercury/EmArcy Records"></a></div>
            <div><a href="https://concord.com/labels/prestige-records/" target="_blank"><img src="../app/images/logo_prestige.png" title="Prtestige Records" alt="Prestige Records"></a></div>
            <div><a href="https://www.universalmusic.com/label/capitol-music-group/" target="_blank"><img src="../app/images/logo_pacific.png" title="Pacific Jazz" alt="Pacific Jazz"></a></div>
            <div><a href="https://concord.com/labels/savoy-label-group/" target="_blank"><img src="../app/images/logo_savoy.png" title="Savoy Records" alt="Savoy Records"></a></div>
        </div>
    </div>
</div>
<!--Dešimta dalis Contact us-->
<section class="contactus">
    <div class="container">
        <div class="contactus-heading">
            <div class="contact-text">
                <h2>Don't hesitate to contact us anytime</h2>
                <p>There are many roads to jazz, as any collection of fans will demonstrate. But for many of those fans, whose age today can fall anywhere between 10 and 80, that road has been paved with Ronnie Scott's Jazz club.</p>
            </div>
            <button class ="getQuote">Get a Quote</button>
        </div>
    </div>              
</section>       
<!--Vienuolikta dalis About Us dalis-->
<div class="aboutus">
    <div class="container">
        <div class="aboutus-content flex-container">
            <div class="about-parts zero-nav">
                <a href="#jazz-hero"><img src="../app/images/logo_footer.png" alt="Magma Jazz"></a>
                <p>British jazz tenor saxophonist Ronnie Scott  co-founded Ronnie Scott's Jazz Club, one of the world's most popular jazz clubs, from 1959.</p>
                <nav class="social-nav">
                    <ul class="flex-container">
                        <li><a href="https://facebook.com"  target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="https://www.spotify.com"  target="_blank"><i class="fab fa-spotify"></i></a></li>
                        <li><a href="https://www.deezer.com"  target="_blank"><i class="fab fa-deezer"></i></a></li>
                        <li><a href="https://music.youtube.com"  target="_blank"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </nav>
            </div>
            <div class="about-parts first-navhead">
                <h2>Our Company</h2> 
                <ul class="bottom-nav first-nav">
                    <li><a href="#jazz-hero">Home</a></li>
                    <li><br></li>
                    <li><a href="#records">Records</a></li>
                    <li><br></li>
                    <li><a href="#jstyles">JStyles</a></li>
                    <li><br></li>
                    <li><a href="#contact-heading">Contact</a></li>
                </ul>
            </div>
            <div class="about-parts second-navhead">
                <h2>Useful Links</h2> 
                    <ul class="bottom-nav second-nav">
                        <li><a href="https://www.ecmrecords.com/home" target="_blank">ECM Records</a></li>
                        <li><br></li>
                        <li><a href="https://www.okeh-records.com" target="_blank">Okeh Records</a></li>
                        <li><br></li>
                        <li><a href="https://www.actmusic.com" target="_blank">ACT Music</a></li>
                        <li><br></li>
                        <li><a href="https://www.downbeat.com" target="_blank">DownBeat</a></li>
                    </ul>
            </div>
            <div class="about-parts third-navhead">
                <h2>Contact Info</h2> 
                    <ul class="bottom-nav third-nav">
                        <li><a href="https://goo.gl/maps/w2eHpSDSEPg8VUSF7" target="_blank"><i class="fas fa-map-marker-alt"></i>  47 Frith St, Soho, London</a></li>
                        <li style="padding-left:1.1em"><a href="https://goo.gl/maps/w2eHpSDSEPg8VUSF7" target="_blank">W1D 4HT, United Kingdom</a></li>               
                        <li><br></li>
                        <li><a href="tel:+4402074390747"><i class="fas fa-phone-alt"></i> +44 (020) 743 90747</a></li>
                        <li><br></li>
                        <li><a href="mailto:ronniescotts@ronniescotts.co.uk"><i class="fas fa-envelope"></i> ronniescotts@ronniescotts.co.uk</a></li>  
                        <li><br></li>
                        <li><i class="far fa-clock"></i> Sun: 6:30 PM - 12:00 AM.</li>
                        <li style="padding-left:1.2em">Mon–Sat: 6:00PM - 3:00 AM</li>
                    </ul>
            </div>
        </div>                
    </div>
</div>
