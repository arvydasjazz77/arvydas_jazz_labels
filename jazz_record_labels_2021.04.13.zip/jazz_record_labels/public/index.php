<?php
    require __DIR__ . '/../app/src/app.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>The Greatest Jazz Record Labels</title>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&family=Open+Sans:ital@0;1&family=Poppins&family=Righteous&family=Roboto:ital@0;1&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/3341df22e3.js" crossorigin="anonymous"></script>    
        <link rel="stylesheet" href="../app/css/normalize.css">
        <link rel="stylesheet" href="../app/css/style.css">    
    </head>
    <body>
        <?php
            include('../app/views/header.php');
            include('../app/views/content.php');
            include('../app/views/footer.php');
        ?>
        <script src="../app/scripts/jquery.min.js"></script>
        <script src="../app/scripts/jazz.js"></script>
    </body>
</html>